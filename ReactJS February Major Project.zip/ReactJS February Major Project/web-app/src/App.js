import './App.css';
import Bachground from './components/Bachground';
import Home from './components/Home';
import Menu from './components/Menu';
import Review from './components/Review';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { BrowserRouter, Route, Routes } from "react-router-dom"

function App() {
  return (
<BrowserRouter>
    <Routes>
      <Route path='/' element={<><Bachground/><Home/><Menu/><Review/><Contact/><Footer/></>}/>
      <Route path='/about' element={<><Bachground/><Home/><Menu/><Review/><Contact/><Footer/></>}/>
      <Route path='/menu' element={<><Bachground/><Home/><Menu/><Review/><Contact/><Footer/></>}/>
      <Route path='/reviews' element={<><Bachground/><Home/><Menu/><Review/><Contact/><Footer/></>}/>
      <Route path='/contact' element={<><Bachground/><Home/><Menu/><Review/><Contact/><Footer/></>}/> 
    </Routes>
    </BrowserRouter>
  )
}

export default App;
